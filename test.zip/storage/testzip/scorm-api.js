window.API = {
  LMSCommit: function(callback) {
    fetch('/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: 1,
        scormId: 'curso-exemplo',
        scoId: 'intro',
        status: 'completed',
        score: 100
      })
    })
    .then(res => res.json())
    .then(data => {
      console.log('Tracking Intro Response:', data);
      if (callback) callback(); // chama callback depois do tracking
    });
  },
  LMSCommitQuiz: function() {
    fetch('/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: 1,
        scormId: 'curso-exemplo',
        scoId: 'quiz',
        status: 'completed',
        score: 90
      })
    })
    .then(res => res.json())
    .then(data => console.log('Tracking Quiz Response:', data));
  }
};
